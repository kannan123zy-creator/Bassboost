package com.example.bassboost

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {

    private lateinit var spotify: SpotifyManager

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { startForegroundService(Intent(this, AudioEngineService::class.java)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        spotify = SpotifyManager(this)

        permissions.launch(arrayOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.POST_NOTIFICATIONS
        ))

        setContent { BassBoostTheme { Screen(spotify) { spotify.login(this) } } }
    }

    @Deprecated("Auth SDK still delivers results here")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == SpotifyManager.AUTH_REQUEST_CODE) spotify.handleAuthResult(res, data)
    }

    override fun onStop() { super.onStop() /* keep remote alive for background control */ }
    override fun onDestroy() { spotify.disconnect(); super.onDestroy() }
}

// ---------- Theme ----------
private val Bg = Color(0xFF0D0D12)
private val Card = Color(0xFF1A1A24)
private val Accent = Color(0xFF1ED760)

@Composable
fun BassBoostTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card),
    content = content
)

// ---------- Screen ----------
@Composable
fun Screen(spotify: SpotifyManager, onLogin: () -> Unit) {
    val s by DspEngine.settings.collectAsStateWithLifecycle()
    val bt by BtState.deviceName.collectAsStateWithLifecycle()

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        BluetoothBar(bt)

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Audio Enhancer", style = MaterialTheme.typography.headlineSmall,
                color = Color.White, modifier = Modifier.weight(1f))
            Switch(s.enabled, { DspEngine.update(s.copy(enabled = it)) })
        }

        DspSlider("Bass Boost", "${s.bassPercent}%", s.bassPercent.toFloat(), 0f..100f) {
            DspEngine.update(s.copy(bassPercent = it.toInt()))
        }
        DspSlider("Gain", "+${"%.1f".format(s.gainDb)} dB", s.gainDb, 0f..20f) {
            DspEngine.update(s.copy(gainDb = it))
        }
        DspSlider("Vocal Boost", "${s.vocalPercent}%", s.vocalPercent.toFloat(), 0f..100f) {
            DspEngine.update(s.copy(vocalPercent = it.toInt()))
        }

        Spacer(Modifier.weight(1f))
        SpotifyBar(spotify, onLogin)
    }
}

@Composable
fun BluetoothBar(name: String?) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape)
            .background(if (name != null) Accent else Color.Gray))
        Spacer(Modifier.width(10.dp))
        Text(name?.let { "Connected: $it" } ?: "No Bluetooth speaker connected",
            color = Color.White)
    }
}

@Composable
fun DspSlider(label: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>,
              onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(16.dp)) {
        Row {
            Text(label, color = Color.White, modifier = Modifier.weight(1f))
            Text(value, color = Accent)
        }
        Slider(v, onChange, valueRange = range)
    }
}

@Composable
fun SpotifyBar(spotify: SpotifyManager, onLogin: () -> Unit) {
    val connected by spotify.connected.collectAsStateWithLifecycle()
    val np by spotify.nowPlaying.collectAsStateWithLifecycle()

    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!connected) {
            Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) {
                Text("Log in with Spotify")
            }
            return@Row
        }
        np?.art?.let {
            Image(it.asImageBitmap(), null,
                Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)))
        }
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(np?.title ?: "Nothing playing", color = Color.White, maxLines = 1)
            Text(np?.artist ?: "", color = Color.Gray, maxLines = 1)
        }
        TextButton({ spotify.previous() }) { Text("⏮") }
        TextButton({ spotify.togglePlayPause() }) { Text(if (np?.isPaused == false) "⏸" else "▶") }
        TextButton({ spotify.next() }) { Text("⏭") }
    }
}
