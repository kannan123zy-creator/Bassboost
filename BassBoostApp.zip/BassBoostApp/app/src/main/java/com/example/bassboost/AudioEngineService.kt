package com.example.bassboost

import android.app.*
import android.content.*
import android.bluetooth.BluetoothDevice
import android.media.audiofx.AudioEffect
import android.os.IBinder

/**
 * Foreground service that keeps the DSP chain alive while audio plays in the background.
 * - Attaches effects to session 0 (global mix; unreliable on newer Android).
 * - Attaches to any session a player announces via OPEN_AUDIO_EFFECT_CONTROL_SESSION.
 */
class AudioEngineService : Service() {

    private val btReceiver = BluetoothReceiver()

    private val sessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, i: Intent) {
            val id = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (id <= 0) return
            when (i.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> DspEngine.attach(id)
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> DspEngine.detach(id)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())

        DspEngine.attach(0)
        registerReceiver(sessionReceiver, IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }, Context.RECEIVER_EXPORTED)
        registerReceiver(btReceiver, IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }, Context.RECEIVER_EXPORTED)

        BtState.refresh(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        unregisterReceiver(sessionReceiver)
        unregisterReceiver(btReceiver)
        DspEngine.releaseAll()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "dsp"
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "Audio engine", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("BassBoost active")
            .setContentText("Audio enhancement running")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }
}
