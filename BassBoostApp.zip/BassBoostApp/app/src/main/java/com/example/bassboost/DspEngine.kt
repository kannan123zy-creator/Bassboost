package com.example.bassboost

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import kotlinx.coroutines.flow.MutableStateFlow

/** UI-facing settings (single source of truth). */
data class DspSettings(
    val enabled: Boolean = true,
    val bassPercent: Int = 0,      // 0..100
    val gainDb: Float = 0f,        // 0..20 dB
    val vocalPercent: Int = 0      // 0..100
)

/**
 * Wraps Android AudioEffect APIs. Singleton so the Service and UI share state.
 * Effects can be attached to several sessions (0 = global mix, or a player's session id).
 */
object DspEngine {
    val settings = MutableStateFlow(DspSettings())

    private class Chain(val session: Int) {
        val bass = BassBoost(0, session)
        val eq = Equalizer(0, session)
        val loud = LoudnessEnhancer(session)
        fun release() { bass.release(); eq.release(); loud.release() }
    }

    private val chains = mutableMapOf<Int, Chain>()

    /** Attach (or re-attach) effects to an audio session. Safe to call repeatedly. */
    @Synchronized
    fun attach(session: Int) {
        if (chains.containsKey(session)) return
        try {
            chains[session] = Chain(session).also { apply(it, settings.value) }
        } catch (e: Exception) {
            // Some devices reject session 0 or unsupported effects – fail quietly.
        }
    }

    @Synchronized
    fun detach(session: Int) { chains.remove(session)?.release() }

    @Synchronized
    fun releaseAll() { chains.values.forEach { it.release() }; chains.clear() }

    @Synchronized
    fun update(new: DspSettings) {
        settings.value = new
        chains.values.forEach { apply(it, new) }
    }

    private fun apply(c: Chain, s: DspSettings) {
        try {
            c.bass.enabled = s.enabled
            c.eq.enabled = s.enabled
            c.loud.enabled = s.enabled

            // Bass: strength is 0..1000
            if (c.bass.strengthSupported) c.bass.setStrength((s.bassPercent * 10).toShort())

            // Gain: target gain in millibels (100 mB = 1 dB). Applied as a soft pre-amp.
            c.loud.setTargetGain((s.gainDb * 100).toInt())

            applyVocal(c.eq, s.vocalPercent)
        } catch (_: Exception) { }
    }

    /**
     * Vocal clarity: raise bands whose centre frequency is 1–4 kHz.
     * getCenterFreq() returns milliHertz, so 1 kHz = 1_000_000.
     * Boost is capped at ~60% of the band range to limit distortion.
     */
    private fun applyVocal(eq: Equalizer, percent: Int) {
        val max = eq.bandLevelRange[1]
        for (band in 0 until eq.numberOfBands) {
            val hz = eq.getCenterFreq(band.toShort()) / 1000
            val inVocalRange = hz in 1000..4000
            val level = if (inVocalRange) (max * 0.6f * percent / 100f).toInt() else 0
            eq.setBandLevel(band.toShort(), level.toShort())
        }
    }
}
