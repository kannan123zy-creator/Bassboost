package com.example.bassboost

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import kotlinx.coroutines.flow.MutableStateFlow

object BtState {
    /** Name of the active Bluetooth audio output, or null if none. */
    val deviceName = MutableStateFlow<String?>(null)

    /** Ask AudioManager which Bluetooth sink is currently an output (no extra permission needed). */
    fun refresh(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val bt = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER
        }
        deviceName.value = bt?.productName?.toString()
    }
}

/** Listens for ACL connect/disconnect and refreshes the active sink. Registered by the Service. */
class BluetoothReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                // Give the A2DP profile a moment to become the active route.
                android.os.Handler(ctx.mainLooper).postDelayed({ BtState.refresh(ctx) }, 1500)
            }
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> BtState.refresh(ctx)
        }
    }
}
