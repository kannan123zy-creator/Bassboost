package com.example.bassboost

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import com.spotify.android.appremote.api.ConnectionParams
import com.spotify.android.appremote.api.Connector
import com.spotify.android.appremote.api.SpotifyAppRemote
import com.spotify.protocol.types.Image
import com.spotify.sdk.android.auth.AuthorizationClient
import com.spotify.sdk.android.auth.AuthorizationRequest
import com.spotify.sdk.android.auth.AuthorizationResponse
import kotlinx.coroutines.flow.MutableStateFlow

/** Handles Spotify OAuth (Auth SDK) + playback control/metadata (App Remote SDK). */
class SpotifyManager(private val ctx: Context) {

    companion object {
        const val CLIENT_ID = "YOUR_SPOTIFY_CLIENT_ID"        // <-- paste yours
        const val REDIRECT_URI = "bassboost://callback"       // must match dashboard
        const val AUTH_REQUEST_CODE = 1337
    }

    data class NowPlaying(
        val title: String, val artist: String, val art: Bitmap?, val isPaused: Boolean
    )

    val nowPlaying = MutableStateFlow<NowPlaying?>(null)
    val connected = MutableStateFlow(false)
    var accessToken: String? = null   // use for Web API calls (e.g. search, playlists)
        private set

    private var remote: SpotifyAppRemote? = null

    /** Step 1: launch Spotify login (OAuth 2.0). */
    fun login(activity: Activity) {
        val req = AuthorizationRequest.Builder(
            CLIENT_ID, AuthorizationResponse.Type.TOKEN, REDIRECT_URI
        ).setScopes(arrayOf(
            "app-remote-control", "user-read-playback-state",
            "user-modify-playback-state", "streaming"
        )).build()
        AuthorizationClient.openLoginActivity(activity, AUTH_REQUEST_CODE, req)
    }

    /** Step 2: call from Activity.onActivityResult. */
    fun handleAuthResult(resultCode: Int, data: Intent?) {
        val r = AuthorizationClient.getResponse(resultCode, data)
        if (r.type == AuthorizationResponse.Type.TOKEN) {
            accessToken = r.accessToken
            connectRemote()
        }
    }

    /** Step 3: connect to the Spotify app and subscribe to player state. */
    fun connectRemote() {
        val params = ConnectionParams.Builder(CLIENT_ID)
            .setRedirectUri(REDIRECT_URI)
            .showAuthView(true)
            .build()

        SpotifyAppRemote.connect(ctx, params, object : Connector.ConnectionListener {
            override fun onConnected(r: SpotifyAppRemote) {
                remote = r
                connected.value = true
                r.playerApi.subscribeToPlayerState().setEventCallback { state ->
                    val t = state.track ?: return@setEventCallback
                    r.imagesApi.getImage(t.imageUri, Image.Dimension.MEDIUM)
                        .setResultCallback { bmp ->
                            nowPlaying.value =
                                NowPlaying(t.name, t.artist.name, bmp, state.isPaused)
                        }
                }
            }
            override fun onFailure(e: Throwable) { connected.value = false }
        })
    }

    fun togglePlayPause() {
        val api = remote?.playerApi ?: return
        api.playerState.setResultCallback { if (it.isPaused) api.resume() else api.pause() }
    }
    fun next() { remote?.playerApi?.skipNext() }
    fun previous() { remote?.playerApi?.skipPrevious() }

    fun disconnect() { remote?.let { SpotifyAppRemote.disconnect(it) }; connected.value = false }
}
