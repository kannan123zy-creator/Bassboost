plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose") // Kotlin 2.x
}

android {
    namespace = "com.example.bassboost"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.bassboost"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Spotify auth redirect scheme
        manifestPlaceholders["redirectSchemeName"] = "bassboost"
        manifestPlaceholders["redirectHostName"] = "callback"
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")

    // Spotify: App Remote is a local AAR you download manually (see README)
    implementation(files("libs/spotify-app-remote-release-0.8.0.aar"))
    implementation("com.google.code.gson:gson:2.11.0") // required by App Remote
    implementation("com.spotify.android:auth:2.1.1")    // Auth library
}
