# BassBoost – Bluetooth Audio Control (Android, Kotlin + Compose)

## Setup
1. Create an Android Studio project with package `com.example.bassboost`, then copy these files over it.
2. Download the **Spotify App Remote SDK** (`spotify-app-remote-release-x.y.z.aar`) from
   https://developer.spotify.com/documentation/android and put it in `app/libs/`.
3. Create an app at https://developer.spotify.com/dashboard. Set redirect URI `bassboost://callback`,
   add your package name + SHA-1 fingerprint, and paste the Client ID into `SpotifyManager.kt`.
4. Build, install, and open Spotify once on the same phone (App Remote controls the Spotify app).

## Important limits (read this)
- **Spotify audio can't be streamed inside your app.** App Remote only *controls* the Spotify app.
  Spotify Premium is required for playback control.
- **Audio session 0 (global mix) is deprecated** and ignored on many Android 9+ devices.
  The service therefore also listens for `ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION` broadcasts
  and attaches effects to whatever session a player announces. If a player never announces
  one, effects won't apply on that device.
- Keep Gain below ~+12 dB on loud tracks to avoid clipping.
